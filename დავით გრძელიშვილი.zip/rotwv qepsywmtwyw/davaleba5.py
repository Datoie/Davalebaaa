def fourht_func(arr):
    finnal_arr = []
    new_arr=sorted([[ len(i), i] for i in arr])
    for i in new_arr:
        finnal_arr.append(i[1])
    return finnal_arr
print(fourht_func(['1111','asdasasdadasdasdasdasdadasdadasdasd','2224444444422','333333']))