def fourht_func(arr):
    arr = list(set(arr))
    new_arr = []
    for i in range(len(arr)):
        new_arr.append([i,arr.count(arr[i])])
    return new_arr
print(fourht_func([1,1,1,11,1,11,2,2,2,23,33,]))