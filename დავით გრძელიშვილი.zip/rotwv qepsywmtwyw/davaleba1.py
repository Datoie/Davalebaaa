def first_funk (arr):
    new_arr = []
    for i in arr:
        if i % 2 ==0:
            new_arr.append(str(i))
    rseult = '-'.join(new_arr[::-1])  
    return rseult
print(first_funk([1, 48, 16, 2, 3, 97 ,100, 15, 13]))