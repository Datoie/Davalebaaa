def second_funk(arr):
    new_arr  = []
    for i in arr:
        if str(i)== '0':
            new_arr.append('Z')
        elif not str(i).isnumeric():
            new_arr.append('L')
        else:
            new_arr.append('N')
        result = ''.join(new_arr)
    return result
print(second_funk(['0', 'm', 'm', 123, '0','m',1]))
print(second_funk(['0', 'm', 1 , 8, 'n',10 ,'s'])) # ZLNNLNL

#zllnzln