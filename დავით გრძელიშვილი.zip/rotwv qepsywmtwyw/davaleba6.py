def fourht_func(x):
    x = x.lower()
    new_str=''
    for i in x.lower():
        if x.count(i) == 1:
            new_str +=i
            break
        elif x.count(i) >2 and x.count(i) >1:
            new_str ='mgeli2020'
    return new_str

print(fourht_func('Tractori'))
print(fourht_func('TesreSs'))
print(fourht_func(' დდააავვიი'))
print(fourht_func('დდააავვიი'))