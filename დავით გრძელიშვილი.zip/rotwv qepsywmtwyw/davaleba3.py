def therd_fucn(arr):
    new_arr = []
    for i in arr:
        new_arr.append(chr(i))
    result = "".join(new_arr)
    return result
print(therd_fucn([103, 111, 97]))