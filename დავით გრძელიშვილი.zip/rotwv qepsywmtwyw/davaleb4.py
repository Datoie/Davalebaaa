def fourht_func(arr):
    result = 0
    new_char = arr[0]
    for i in arr:
        if len(new_char) > len(i):
            new_char = i
    return new_char
print(fourht_func(['goal', 'oreintadze','s', 'acad']))